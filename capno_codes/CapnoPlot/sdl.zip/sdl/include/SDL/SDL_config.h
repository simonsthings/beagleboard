/* include/SDL_config.h.  Generated from SDL_config.h.in by configure.  */
/* include/SDL_config.h.in.  Generated from configure.in by autoheader.  */

/* Define to one of `_getb67', `GETB67', `getb67' for Cray-2 and Cray-YMP
   systems. This function is required for `alloca.c' support on those systems.
   */
/* #undef CRAY_STACKSEG_END */

/* Define to 1 if using `alloca.c'. */
/* #undef C_ALLOCA */

/* Define to 1 if you have the `abs' function. */
#define HAVE_ABS 1

/* Define to 1 if you have `alloca', as a function or macro. */
#define HAVE_ALLOCA 1

/* Define to 1 if you have <alloca.h> and it should be used (not on Ultrix).
   */
#define HAVE_ALLOCA_H 1

/* "" */
/* #undef HAVE_ALTIVEC_H */

/* Define to 1 if you have the `atof' function. */
#define HAVE_ATOF 1

/* Define to 1 if you have the `atoi' function. */
#define HAVE_ATOI 1

/* Define to 1 if you have the `bcopy' function. */
#define HAVE_BCOPY 1

/* Define to 1 if you have the `calloc' function. */
#define HAVE_CALLOC 1

/* "" */
/* #undef HAVE_CLOCK_GETTIME */

/* Define to 1 if you have the <ctype.h> header file. */
#define HAVE_CTYPE_H 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* "" */
#define HAVE_DLVSYM 1

/* Define to 1 if you have the `free' function. */
#define HAVE_FREE 1

/* Define to 1 if you have the `getenv' function. */
#define HAVE_GETENV 1

/* Define to 1 if you have the `iconv' function. */
#define HAVE_ICONV 1

/* Define to 1 if you have the <iconv.h> header file. */
#define HAVE_ICONV_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the `itoa' function. */
/* #undef HAVE_ITOA */

/* "" */
#define HAVE_LIBC 1

/* Define to 1 if you have the `malloc' function. */
#define HAVE_MALLOC 1

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the <math.h> header file. */
#define HAVE_MATH_H 1

/* "" */
#define HAVE_MEMCMP 1

/* Define to 1 if you have the `memcpy' function. */
#define HAVE_MEMCPY 1

/* Define to 1 if you have the `memmove' function. */
#define HAVE_MEMMOVE 1

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the `memset' function. */
#define HAVE_MEMSET 1

/* Define to 1 if you have the `nanosleep' function. */
#define HAVE_NANOSLEEP 1

/* Define to 1 if you have the `putenv' function. */
#define HAVE_PUTENV 1

/* Define to 1 if you have the `qsort' function. */
#define HAVE_QSORT 1

/* Define to 1 if you have the `realloc' function. */
#define HAVE_REALLOC 1

/* Define to 1 if you have the `setjmp' function. */
#define HAVE_SETJMP 1

/* Define to 1 if you have the `sigaction' function. */
#define HAVE_SIGACTION 1

/* Define to 1 if you have the <signal.h> header file. */
#define HAVE_SIGNAL_H 1

/* Define to 1 if you have the `snprintf' function. */
#define HAVE_SNPRINTF 1

/* Define to 1 if you have the `sscanf' function. */
#define HAVE_SSCANF 1

/* Define to 1 if you have the <stdarg.h> header file. */
#define HAVE_STDARG_H 1

/* Define to 1 if you have the <stddef.h> header file. */
#define HAVE_STDDEF_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the `strcasecmp' function. */
#define HAVE_STRCASECMP 1

/* Define to 1 if you have the `strchr' function. */
#define HAVE_STRCHR 1

/* Define to 1 if you have the `strcmp' function. */
#define HAVE_STRCMP 1

/* Define to 1 if you have the `strdup' function. */
#define HAVE_STRDUP 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strlcat' function. */
/* #undef HAVE_STRLCAT */

/* Define to 1 if you have the `strlcpy' function. */
/* #undef HAVE_STRLCPY */

/* Define to 1 if you have the `strlen' function. */
#define HAVE_STRLEN 1

/* Define to 1 if you have the `strncasecmp' function. */
#define HAVE_STRNCASECMP 1

/* Define to 1 if you have the `strncmp' function. */
#define HAVE_STRNCMP 1

/* Define to 1 if you have the `strrchr' function. */
#define HAVE_STRRCHR 1

/* Define to 1 if you have the `strstr' function. */
#define HAVE_STRSTR 1

/* "" */
/* #undef HAVE_STRTOD */

/* Define to 1 if you have the `strtol' function. */
#define HAVE_STRTOL 1

/* Define to 1 if you have the `strtoll' function. */
#define HAVE_STRTOLL 1

/* Define to 1 if you have the `strtoul' function. */
#define HAVE_STRTOUL 1

/* Define to 1 if you have the `strtoull' function. */
#define HAVE_STRTOULL 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the `unsetenv' function. */
#define HAVE_UNSETENV 1

/* Define to 1 if you have the `vsnprintf' function. */
#define HAVE_VSNPRINTF 1

/* Define to 1 if you have the `_i64toa' function. */
/* #undef HAVE__I64TOA */

/* Define to 1 if you have the `_ltoa' function. */
/* #undef HAVE__LTOA */

/* Define to 1 if you have the `_stricmp' function. */
/* #undef HAVE__STRICMP */

/* Define to 1 if you have the `_strlwr' function. */
/* #undef HAVE__STRLWR */

/* Define to 1 if you have the `_strnicmp' function. */
/* #undef HAVE__STRNICMP */

/* Define to 1 if you have the `_strrev' function. */
/* #undef HAVE__STRREV */

/* Define to 1 if you have the `_strupr' function. */
/* #undef HAVE__STRUPR */

/* Define to 1 if you have the `_ui64toa' function. */
/* #undef HAVE__UI64TOA */

/* Define to 1 if you have the `_uitoa' function. */
/* #undef HAVE__UITOA */

/* Define to 1 if you have the `_ultoa' function. */
/* #undef HAVE__ULTOA */

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#define LT_OBJDIR ".libs/"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME ""

/* Define to the full name and version of this package. */
#define PACKAGE_STRING ""

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME ""

/* Define to the version of this package. */
#define PACKAGE_VERSION ""

/* "" */
/* #undef SDL_ALTIVEC_BLITTERS */

/* "" */
#define SDL_ASSEMBLY_ROUTINES 1

/* "" */
/* #undef SDL_AUDIO_DISABLED */

/* "" */
/* #undef SDL_AUDIO_DRIVER_ARTS */

/* 1 */
/* #undef SDL_AUDIO_DRIVER_ARTS_DYNAMIC */

/* "" */
/* #undef SDL_AUDIO_DRIVER_BAUDIO */

/* "" */
/* #undef SDL_AUDIO_DRIVER_BSD */

/* "" */
/* #undef SDL_AUDIO_DRIVER_COREAUDIO */

/* "" */
/* #undef SDL_AUDIO_DRIVER_DISK */

/* "" */
/* #undef SDL_AUDIO_DRIVER_DMEDIA */

/* "" */
/* #undef SDL_AUDIO_DRIVER_DSOUND */

/* "" */
#define SDL_AUDIO_DRIVER_DUMMY 1

/* "" */
/* #undef SDL_AUDIO_DRIVER_ESD */

/* "" */
/* #undef SDL_AUDIO_DRIVER_ESD_DYNAMIC */

/* "" */
/* #undef SDL_AUDIO_DRIVER_MINT */

/* "" */
/* #undef SDL_AUDIO_DRIVER_MMEAUDIO */

/* "" */
/* #undef SDL_AUDIO_DRIVER_NAS */

/* "" */
#define SDL_AUDIO_DRIVER_OSS 1

/* "" */
/* #undef SDL_AUDIO_DRIVER_OSS_SOUNDCARD_H */

/* "" */
/* #undef SDL_AUDIO_DRIVER_PAUD */

/* "" */
/* #undef SDL_AUDIO_DRIVER_QNXNTO */

/* "" */
/* #undef SDL_AUDIO_DRIVER_SNDMGR */

/* "" */
/* #undef SDL_AUDIO_DRIVER_SUNAUDIO */

/* "" */
/* #undef SDL_AUDIO_DRIVER_WAVEOUT */

/* "Byte Order" */
#define SDL_BYTEORDER 1234

/* "" */
/* #undef SDL_CDROM_AIX */

/* "" */
/* #undef SDL_CDROM_BEOS */

/* "" */
/* #undef SDL_CDROM_BSDI */

/* "" */
/* #undef SDL_CDROM_DISABLED */

/* "" */
/* #undef SDL_CDROM_FREEBSD */

/* "" */
#define SDL_CDROM_LINUX 1

/* "" */
/* #undef SDL_CDROM_MACOSX */

/* "" */
/* #undef SDL_CDROM_MINT */

/* "" */
/* #undef SDL_CDROM_OPENBSD */

/* "" */
/* #undef SDL_CDROM_OSF */

/* "" */
/* #undef SDL_CDROM_QNX */

/* "" */
/* #undef SDL_CDROM_WIN32 */

/* "" */
/* #undef SDL_CPUINFO_DISABLED */

/* "" */
/* #undef SDL_EVENTS_DISABLED */

/* "" */
/* #undef SDL_FILE_DISABLED */

/* "" */
#define SDL_HAS_64BIT_TYPE 1

/* "" */
/* #undef SDL_HERMES_BLITTERS */

/* "" */
#define SDL_INPUT_LINUXEV 1

/* "" */
#define SDL_INPUT_TSLIB 1

/* "" */
/* #undef SDL_JOYSTICK_BEOS */

/* "" */
/* #undef SDL_JOYSTICK_DISABLED */

/* "" */
/* #undef SDL_JOYSTICK_IOKIT */

/* "" */
#define SDL_JOYSTICK_LINUX 1

/* "" */
/* #undef SDL_JOYSTICK_MINT */

/* "" */
/* #undef SDL_JOYSTICK_RISCOS */

/* "" */
/* #undef SDL_JOYSTICK_USBHID */

/* "" */
/* #undef SDL_JOYSTICK_USBHID_MACHINE_JOYSTICK_H */

/* "" */
/* #undef SDL_JOYSTICK_WINMM */

/* "" */
/* #undef SDL_LOADSO_BEOS */

/* "" */
/* #undef SDL_LOADSO_DISABLED */

/* "" */
/* #undef SDL_LOADSO_DLCOMPAT */

/* "" */
#define SDL_LOADSO_DLOPEN 1

/* "" */
/* #undef SDL_LOADSO_LDG */

/* "" */
/* #undef SDL_LOADSO_WIN32 */

/* "" */
/* #undef SDL_THREADS_DISABLED */

/* "" */
/* #undef SDL_THREAD_BEOS */

/* "" */
/* #undef SDL_THREAD_PTH */

/* "" */
#define SDL_THREAD_PTHREAD 1

/* "" */
#define SDL_THREAD_PTHREAD_RECURSIVE_MUTEX 1

/* "" */
/* #undef SDL_THREAD_PTHREAD_RECURSIVE_MUTEX_NP */

/* "" */
/* #undef SDL_THREAD_SPROC */

/* "" */
/* #undef SDL_THREAD_WIN32 */

/* "" */
/* #undef SDL_TIMERS_DISABLED */

/* "" */
/* #undef SDL_TIMER_BEOS */

/* ""T */
/* #undef SDL_TIMER_MIN */

/* "" */
/* #undef SDL_TIMER_RISCOS */

/* "" */
#define SDL_TIMER_UNIX 1

/* "" */
/* #undef SDL_TIMER_WIN32 */

/* "" */
/* #undef SDL_VIDEO_DISABLED */

/* "" */
/* #undef SDL_VIDEO_DRIVER_AALIB */

/* "" */
/* #undef SDL_VIDEO_DRIVER_BWINDOW */

/* "" */
/* #undef SDL_VIDEO_DRIVER_DDRAW */

/* "" */
/* #undef SDL_VIDEO_DRIVER_DGA */

/* "" */
/* #undef SDL_VIDEO_DRIVER_DIRECTFB */

/* "" */
/* #undef SDL_VIDEO_DRIVER_DUMMY */

/* "" */
#define SDL_VIDEO_DRIVER_FBCON 1

/* "" */
/* #undef SDL_VIDEO_DRIVER_GEM */

/* "" */
/* #undef SDL_VIDEO_DRIVER_GGI */

/* "" */
/* #undef SDL_VIDEO_DRIVER_IPOD */

/* "" */
/* #undef SDL_VIDEO_DRIVER_NANOX */

/* "" */
/* #undef SDL_VIDEO_DRIVER_PHOTON */

/* "" */
/* #undef SDL_VIDEO_DRIVER_PICOGUI */

/* "" */
/* #undef SDL_VIDEO_DRIVER_PS2GS */

/* "" */
/* #undef SDL_VIDEO_DRIVER_QTOPIA */

/* "" */
/* #undef SDL_VIDEO_DRIVER_QUARTZ */

/* "" */
/* #undef SDL_VIDEO_DRIVER_RISCOS */

/* "" */
/* #undef SDL_VIDEO_DRIVER_SVGALIB */

/* "" */
/* #undef SDL_VIDEO_DRIVER_TOOLBOX */

/* "" */
/* #undef SDL_VIDEO_DRIVER_VGL */

/* "" */
/* #undef SDL_VIDEO_DRIVER_WINDIB */

/* "" */
/* #undef SDL_VIDEO_DRIVER_WSCONS */

/* "" */
#define SDL_VIDEO_DRIVER_X11 1

/* "" */
#define SDL_VIDEO_DRIVER_X11_DGAMOUSE 1

/* "" */
#define SDL_VIDEO_DRIVER_X11_DPMS 1

/* "" */
#define SDL_VIDEO_DRIVER_X11_DYNAMIC "libX11.so.6"

/* "" */
#define SDL_VIDEO_DRIVER_X11_DYNAMIC_XEXT "libXext.so.6"

/* "" */
#define SDL_VIDEO_DRIVER_X11_DYNAMIC_XRANDR "libXrandr.so.2"

/* "" */
#define SDL_VIDEO_DRIVER_X11_DYNAMIC_XRENDER "libXrender.so.1"

/* "" */
#define SDL_VIDEO_DRIVER_X11_VIDMODE 1

/* "" */
#define SDL_VIDEO_DRIVER_X11_XINERAMA 1

/* "" */
#define SDL_VIDEO_DRIVER_X11_XME 1

/* "" */
#define SDL_VIDEO_DRIVER_X11_XRANDR 1

/* "" */
/* #undef SDL_VIDEO_DRIVER_XBIOS */

/* "" */
#define SDL_VIDEO_OPENGL 1

/* "" */
#define SDL_VIDEO_OPENGL_GLX 1

/* "" */
/* #undef SDL_VIDEO_OPENGL_OSMESA */

/* "" */
/* #undef SDL_VIDEO_OPENGL_OSMESA_DYNAMIC */

/* "" */
/* #undef SDL_VIDEO_OPENGL_WGL */

/* The size of `char', as computed by sizeof. */
/* #undef SIZEOF_CHAR */

/* The size of `int', as computed by sizeof. */
/* #undef SIZEOF_INT */

/* The size of `long', as computed by sizeof. */
/* #undef SIZEOF_LONG */

/* The size of `long long', as computed by sizeof. */
/* #undef SIZEOF_LONG_LONG */

/* The size of `short', as computed by sizeof. */
/* #undef SIZEOF_SHORT */

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at runtime.
	STACK_DIRECTION > 0 => grows toward higher addresses
	STACK_DIRECTION < 0 => grows toward lower addresses
	STACK_DIRECTION = 0 => direction of growth unknown */
/* #undef STACK_DIRECTION */

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define to 1 if your processor stores words with the most significant byte
   first (like Motorola and SPARC, unlike Intel and VAX). */
/* #undef WORDS_BIGENDIAN */

/* Define to 1 if the X Window System is missing or not being used. */
/* #undef X_DISPLAY_MISSING */

/* Enable GNU extensions on systems that have them.  */
#ifndef _GNU_SOURCE
# define _GNU_SOURCE 1
#endif

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* "" */
/* #undef int16_t */

/* "" */
/* #undef int32_t */

/* "" */
/* #undef int64_t */

/* "" */
/* #undef int8_t */

/* "" */
/* #undef size_t */

/* "" */
/* #undef uint16_t */

/* "" */
/* #undef uint32_t */

/* "" */
/* #undef uint64_t */

/* "" */
/* #undef uint8_t */

/* "" */
/* #undef uintptr_t */

/* Define to empty if the keyword `volatile' does not work. Warning: valid
   code using `volatile' can become incorrect without. Disable with care. */
/* #undef volatile */
